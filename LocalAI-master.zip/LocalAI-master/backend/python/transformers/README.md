# Creating a separate environment for the transformers project

```
make transformers
```