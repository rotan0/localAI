# Creating a separate environment for the vllm project

```
make vllm
```