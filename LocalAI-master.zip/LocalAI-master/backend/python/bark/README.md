# Creating a separate environment for ttsbark project

```
make ttsbark
```

# Testing the gRPC server

```
<The path of your python interpreter> -m unittest test_ttsbark.py
```

For example
```
/opt/conda/envs/bark/bin/python -m unittest extra/grpc/bark/test_ttsbark.py
``````